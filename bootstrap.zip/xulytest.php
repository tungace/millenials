<?php

echo 'AAA'.$_GET['a'].$_GET['b'].$_GET['loai'];
print_r($_GET);
?>