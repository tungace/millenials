<?php

					$mmhclass->info->config                 = array();
					$mmhclass->info->site_installed         = true;

					/* DATABASE INFORMATION */ 

					$mmhclass->info->config['sql_host']       = "localhost";
					$mmhclass->info->config['sql_username']   = "tuhocielts";
					$mmhclass->info->config['sql_password']   = "123zxcv789";
					$mmhclass->info->config['sql_database']   = "tuhocielts";
					//$mmhclass->info->config['sql_tbl_prefix'] = "mmh_";

?>